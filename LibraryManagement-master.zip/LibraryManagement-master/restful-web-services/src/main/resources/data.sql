insert into todo(id, username,description,target_date,is_done)
values(10001, 'CapgeminiLBS', 'Learn JPA', sysdate(), false);

insert into todo(id, username,description,target_date,is_done)
values(10002, 'CapgeminiLBS', 'Learn Data JPA', sysdate(), false);

insert into todo(id, username,description,target_date,is_done)
values(10003, 'CapgeminiLBS', 'Learn Microservices', sysdate(), false);

insert into todo(id, username,description,target_date,is_done)
values(10004, 'CapgeminiLBS', 'Learn Java', sysdate(), true);

insert into todo(id, username,description,target_date,is_done)
values(20005, 'UserLBS', 'Learn Java', sysdate(), true);