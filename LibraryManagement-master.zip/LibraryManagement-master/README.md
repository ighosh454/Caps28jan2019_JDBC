# LibraryManagement
This is a demp project with Angular, Spring Boot, H2, JWT.
